<template>
    <div>
      <b-modal id="modal-connexion" hide-footer  @hidden="closeModal">
        <template #modal-header>
          <b-link v-if="forgetPasswordModal" variant="link" v-on:click="retourConnexionModal()" class="mt-4" >retour</b-link>
          <h5 class="modal-title text-center">XAYELA</h5>
          <b-button v-on:click="closeModal();" variant="outline-primary"><span aria-hidden="true">&times;</span></b-button>
        </template>
        <Login v-if="connexionModal"/>
        <ForgetPassword v-if="forgetPasswordModal" />
        <!-- <Signup /> -->

      </b-modal>
    </div>
  
</template>

<script>
  import Login from "@/views/Login.vue";
  import ForgetPassword from "@/views/ForgetPassword.vue";

  import { mapGetters, mapMutations } from 'vuex'

  export default {
    name: "ModalConnexion",
    components: {
      Login,
      ForgetPassword
    },
    computed: {
      ...mapGetters(['connexionModal', 'forgetPasswordModal'])
    },
    methods: {
      openModal () {
         this.$bvModal.show('modal-connexion');
      },
      closeModal () {
         this.resetMainConnexionModal()
      },
      retourConnexionModal () {
         this.changeForgetPasswordModalValue();
         this.changeConnexionModalValue();
      },
      ...mapMutations(['resetMainConnexionModal', 'changeForgetPasswordModalValue', 'changeConnexionModalValue']),
    },

    mounted() { 
      this.openModal();
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

  #modal-header .modal-title{
    text-align: center;
  }
</style>
