<template>
  <p>-----</p>
</template>

<script>
// @ is an alias to /src

export default {
  name: "Home",
  components: {
  }
};
</script>
