<template>
    <div>
        <h2 class="my-2 text-center text-uppercase" >Mot de passe oublié</h2>
         <div>
          <b-form  @submit.stop.prevent>
            
            <div v-if="inputTelephone === true">
              <label for="feedback-user">Téléphone</label>         
              <vue-phone-number-input 
                v-model="userId"
                required
                clearable=true
                placeholder="Entrez votre numéro de téléphone Number"        
                default-country-code="CI"
                translations="{
                  phoneNumberLabel: \'Numéro de téléphone\'
                }"
              />
              <b-link variant="link" v-on:click="utiliserEmailOuTelephone()" class="mt-4" >Utiliser un email</b-link>
            </div>
            
            <!--------------------------------->
            <div v-if="inputTelephone === false">
              <label for="feedback-user" >Email ou nom d'utilisateur </label>         
              <b-input 
                v-model="userId" 
              >
              </b-input>
              <b-link variant="link" v-on:click="utiliserEmailOuTelephone()" class="mt-4" >Utiliser un téléphone</b-link>
            </div>
            
            <!--------------------------------->
            
            <div class="text-center">
              <b-button class="mt-3 main-navigation-button " variant="success" v-on:click="reinitialiserMotDePasse()">Réinitialiser mot de passe</b-button>
            </div>
          </b-form>

        </div>
    </div>
  
</template>

<script>
  import VuePhoneNumberInput from 'vue-phone-number-input';
  import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { mapMutations } from 'vuex'


  export default {
    name: "Login",
    data () {
      return {
        userId: '',
        inputTelephone: true
      }
    },
    computed: {
      userValidation() {
        return this.userId.length > 4 && this.userId.length < 13
      }
    },
    components: {
      VuePhoneNumberInput
    },
    methods: {
      utiliserEmailOuTelephone(){
        this.inputTelephone = !this.inputTelephone;
        this.userId = '';
      },
      reinitialiserMotDePasse () {
        //  this.changeConnexionModalValue();
         console.log('mot de passe réinitialisé')
      },
      
      ...mapMutations(['changeConnectedValue', 'changeConnexionModalValue', 'changeForgetPasswordModalValue']),
    },

    mounted() { 
      this.openModal();

    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
