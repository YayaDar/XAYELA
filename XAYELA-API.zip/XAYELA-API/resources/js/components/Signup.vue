<template>
    <div>
      <b-modal id="modal-signup" title="XAYELA"  hide-footer  @hidden="closeModal">
        <p class="my-4 text-center text-uppercase" >Créer un compte</p>
         <div>
          <b-form  @submit.stop.prevent>
            
            <div v-if="inputTelephone === true">
              <label for="feedback-user">Téléphone</label>         
              <vue-phone-number-input 
                v-model="userId"
                required
                clearable=true
                placeholder="Entrez votre numéro de téléphone Number"        
                default-country-code="CI"
                translations="{
                  phoneNumberLabel: \'Numéro de téléphone\'
                }"
              />
              <b-link variant="link" v-on:click="utiliserEmailOuTelephone()" class="mt-4" >Utiliser un email</b-link>
            </div>
            
            <!--------------------------------->
            <div v-if="inputTelephone === false">
              <label for="feedback-user" >Email ou nom d'utilisateur </label>         
              <b-input 
                v-model="userId" 
              >
              </b-input>
              <b-link variant="link" v-if="inputTelephone === false" v-on:click="utiliserEmailOuTelephone()" class="mt-4" >Utiliser un téléphone</b-link>
              <b-link variant="link" v-on:click="utiliserEmailOuTelephone()" class="mt-4" >Utiliser un email</b-link>

              <!-- <b-input 
                v-model="userId" 
                :state="userValidation" id="feedback-user"
              > -->
              <!-- <b-form-invalid-feedback :state="userValidation">
                L'email ou le numéro de téléphone est incorrecte.
              </b-form-invalid-feedback>
              <b-form-valid-feedback :state="userValidation">
                Looks Good.
              </b-form-valid-feedback> -->
            </div>
            
            <!--------------------------------->
            <div>
              <label for="text-password">Password</label>
              <b-input  v-model="password" type="password" id="text-password" aria-describedby="password-help-block"></b-input>
              <!-- <b-form-text id="password-help-block">
                Your password must be 8-20 characters long, contain letters and numbers, and must not
                contain spaces, special characters, or emoji.
              </b-form-text> -->
            </div>
            
            <!--------------------------------->
            <div class="text-center">
              <b-button class="mt-3 main-navigation-button " variant="success" v-on:click="changeConnectedValue()">Se connecter</b-button>
            </div>
          </b-form>

        </div>
      </b-modal>
    </div>
  
</template>

<script>
  import VuePhoneNumberInput from 'vue-phone-number-input';
  import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { mapMutations } from 'vuex'


  export default {
    name: "Signup",
    data () {
      return {
        name: '',
        prenom: '',
        userId: '',
        password: '',
        inputTelephone: true,
        // translationsObject: {
        //   phoneNumberLabel: 'Numéro de téléphone'
        // }
      }
    },
    computed: {
      userValidation() {
        return this.userId.length > 4 && this.userId.length < 13
      }
    },
    components: {
      VuePhoneNumberInput
    },
    methods: {
      utiliserEmailOuTelephone(){
        this.inputTelephone = !this.inputTelephone;
        this.userId = '';
        this.password = '';
      },
       openModal () {
         this.$bvModal.show('modal-signup');
      },
      closeModal () {
         this.changeConnexionModalValue();
      },
      ...mapMutations(['changeConnectedValue', 'changeConnexionModalValue']),
    },

    mounted() { 
      this.openModal();
    },

  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
