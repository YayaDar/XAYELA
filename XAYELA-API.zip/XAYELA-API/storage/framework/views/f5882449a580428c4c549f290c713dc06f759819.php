<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>laravel</title>

    </head>
    <body>
        <h1>XAYELA</h1>
    </body>
</html>
<?php /**PATH C:\Users\diall\XAYELA\resources\views//help.blade.php ENDPATH**/ ?>